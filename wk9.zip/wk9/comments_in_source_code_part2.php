<?php
print "<h1>This is an example of an H1 header tag</h1>";

//print "<!--Created by John Smith with employee id: 123456-->";

print "<h2>H2 tag</h2>";
//print "<!--Created by John Smith with employee id: 123456-->";
print "<h3>H3 tag</h3>";
//print "<!--Created by John Smith with employee id: 123456-->";
print "<h4>H4 tag</h4>";
//print "<!--Created by John Smith with employee id: 123456-->";
print "<h5>H5 tag</h5>";
//print "<!--Created by John Smith with employee id: 123456-->";
print "<h6>H6 tag</h6>";

?>


